document.getElementById('userProfileForm').addEventListener('Enroll now', function(event) {
    event.preventDefault();
    
    const academicBackground = document.getElementById('academicBackground').value;
    const interests = document.getElementById('interests').value;
    const learningGoals = document.getElementById('learningGoals').value;
    const learningStyle = document.getElementById('learningStyle').value;

    // Simulate API call to fetch courses based on user input
    fetchCourses(academicBackground, interests, learningGoals, learningStyle);
});

function fetchCourses(academicBackground, interests, learningGoals, learningStyle) {
    // Mock course data
    const courses = [
        { title: "Introduction to Data Science", duration: "4 weeks", image: "assets/lf-image.jpg" },
        { title: "Web Development Bootcamp", duration: "6 weeks", image: "assets/course-image.jpg" },
        { title: "Machine Learning Basics", duration: "5 weeks", image: "assets/course-image.jpg" }
    ];

    displayCourses(courses);
}

function displayCourses(courses) {
    const coursesContainer = document.getElementById('courses');
    coursesContainer.innerHTML = '';

    courses.forEach(course => {
        const courseCard = `
            <div class="col-md-4 course-card">
                <div class="card">
                    <img src="${course.image}" class="card-img-top" alt="${course.title}">
                    <div class="card-body">
                        <h5 class="card-title">${course.title}</h5>
                        <p class="card-text">Duration: ${course.duration}</p>
                    </div>
                </div>
            </div>
        `;
        coursesContainer.innerHTML += courseCard;
    });

    document.getElementById('courseRecommendations').classList.remove('d-none');
}